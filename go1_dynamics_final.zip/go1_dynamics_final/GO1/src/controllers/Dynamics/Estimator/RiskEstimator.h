#ifndef RISKESTIMATOR_H
#define RISKESTIMATOR_H

// #include "integrating0525.h"
#include <Eigen/Dense>
#include <cmath>
#include <vector>
#include "enum.h"
#include "Dynamics/Calculator/GeneralCalculator.h"
#include <numeric>

class RiskEstimator {
public:
    RiskEstimator();

    bool RiskBaseDecisionMaker( const double SlipProb[4],
                                const Eigen::Vector3d& DistForce, 
                                const Eigen::Vector3d& DistMoment, 
                                const Eigen::Vector3d& imu_rpy_, 
                                double desired_theta_R, 
                                double desired_theta_P);
    double computeRiskScore(double R_slip, double alpha, double R_disturbance, double beta, double R_OrientationError, double gamma);
    double computeSlipRisk(const double slip_prob[4]) ;
    double computeDisturbanceRisk( const double distFx, const double distFy, const double mid_F, const double KF, const double distMx, const double distMy, const double mid_M, const double KM) ;
    double computeOrientationRisk( const double roll,  const double desroll,  const double mid_roll,  const double Kroll, const double pitch, const double despitch, const double mid_pitch, const double Kpitch) ;
    
private:
    // 위험도 계산에 필요한 파라미터
    double alpha = 1.0;  // 미끄러짐 위험도 가중치
    double beta = 2.0;   // 외란 위험도 가중치
    double gamma = 3.0;  // 자세 위험도 가중치

    std::vector<double> risk_history;   // ← 위험도 이력

};

#endif // RISKESTIMATOR_H
