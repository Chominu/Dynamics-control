#include "RiskEstimator.h"

RiskEstimator::RiskEstimator() 
{
}


bool RiskEstimator::RiskBaseDecisionMaker( const double SlipProb[4],
                                            const Eigen::Vector3d& DistForce, 
                                            const Eigen::Vector3d& DistMoment, 
                                            const Eigen::Vector3d& imu_rpy_, 
                                            double desired_theta_R, 
                                            double desired_theta_P)
{

    double distFx = DistForce(0);  double distFy = DistForce(1);  double mid_F = 5000.0;  double KF = 0.005;
    double distMx = DistMoment(0); double distMy = DistMoment(1); double mid_M = 1000.0;  double KM = 0.005;
    double roll   = imu_rpy_(0);   double des_roll = desired_theta_R;  double mid_roll = 0.2;  double Kroll = 20;
    double pitch  = imu_rpy_(1);   double des_pitch = desired_theta_P; double mid_pitch = 0.2; double Kptich = 20;

    // 2. 리스크 점수 계산
    double R_slip        = computeSlipRisk(SlipProb);
    double R_disturbance = computeDisturbanceRisk(distFx,   distFy,     mid_F,      KF,     distMx, distMy,     mid_M,      KM);
    double R_orientation = computeOrientationRisk(roll,     des_roll,   mid_roll,   Kroll,  pitch,  des_pitch,  mid_pitch,  Kptich);
    double RiskScore     = computeRiskScore(R_slip, alpha, R_disturbance, beta, R_orientation, gamma);
    
    // 3. 50스텝 위험 이력 저장
    risk_history.push_back(RiskScore);
    if (risk_history.size() > 50) risk_history.erase(risk_history.begin());

    // 4. 50스텝 평균 위험도 계산
    double recent_risk_mean = std::accumulate(risk_history.begin(), risk_history.end(), 0.0) / risk_history.size();
    
    // 7. 모드 최소 유지 시간 확인 (20초)
    // if (Control_time - last_mode_change_time < 20.0) return;

    // 8. 모드 결정
    return (recent_risk_mean > 0.8);
    // return true;  // 위험도가 높으면 RL 제어로 전환
        // ControlMode = EMERGENCY;
        // std::cout<< "EMERGENCY - > RL Control" << std::endl;
    // else

    // 9. 모드 변경 시 시간 갱신
    // if (new_mode != current_mode) {
        // current_mode = new_mode;
        // last_mode_change_time = Control_time;
    // }

}
// 전체 위험도 계산 
double RiskEstimator::computeRiskScore(double R_slip, double alpha, double R_disturbance, double beta, double R_OrientationError, double gamma)
{
    // 1 - (1-R_slip)^alpha * (1-R_disturbance)^beta * (1-R_OrientationError)^gamma 형식
    // return 1.0 - pow(1-R_slip, alpha) * pow(1-R_disturbance, beta) * pow(1-R_OrientationError, gamma);
    
    //선형 가중 평균 방식
    // return (alpha * R_slip + beta * R_disturbance + gamma * R_OrientationError) / (alpha + beta + gamma);

    // 지수 가중 평균 방식
    double p = 2.0;  // 비선형성 조절 계수
    double numerator = alpha * std::pow(R_slip, p) +
                       beta * std::pow(R_disturbance, p) +
                       gamma * std::pow(R_OrientationError, p);
    double denominator = alpha + beta + gamma;
    return std::pow(numerator / denominator, 1.0 / p);
}
// 미끄러짐 위험도 계산
double RiskEstimator::computeSlipRisk(const double slip_prob[4]) 
{
    double prob_no_slip = 1.0;
    for (int i = 0; i < 4; ++i) {
        prob_no_slip *= (1.0 - slip_prob[i]);  // 모두 미끄러지지 않을 확률
    }
    return 1.0 - prob_no_slip;  // 하나 이상 미끄러질 확률
}
// 외란 위험도 계산
double RiskEstimator::computeDisturbanceRisk( const double distFx, const double distFy, const double mid_F, const double KF,
                                                const double distMx, const double distMy, const double mid_M, const double KM) 
{
    double norm_F = std::hypot(distFx, distFy);
    double norm_M = std::hypot(distMx, distMy);

    double rF = GeneralCalculator::logisticFunction(KF, norm_F, mid_F);
    double rM = GeneralCalculator::logisticFunction(KM, norm_M, mid_M);

    return std::hypot(rF, rM);
}
// 자세 위험도 계산
double RiskEstimator::computeOrientationRisk( const double roll,  const double desroll,  const double mid_roll,  const double Kroll,
                                                const double pitch, const double despitch, const double mid_pitch, const double Kpitch) 
{
    double roll_error   = std::abs(roll - desroll);
    double pitch_error  = std::abs(pitch - despitch);
    double r_roll       = GeneralCalculator::logisticFunction(Kroll, roll_error, mid_roll);
    double r_pitch      = GeneralCalculator::logisticFunction(Kpitch, pitch_error, mid_pitch);

    return std::hypot(r_roll, r_pitch);
}
