#include "SRBM.h"

SingleRigidBody::SingleRigidBody() {
}

SingleRigidBody::~SingleRigidBody() {
}


////////// SRBM QP //////////
Eigen::Matrix<double,12,1> SingleRigidBody::SRBM_QP(const Eigen::Ref<const Eigen::Matrix<double,12,12>>& A,
                                                    const Eigen::Ref<const Eigen::Matrix<double,12,1>>&  b,
                                                    const Eigen::Ref<const Eigen::Matrix<double,24,12>>& G,
                                                    const Eigen::Ref<const Eigen::Matrix<double,24,1>>&  h)
{  
    Eigen::VectorXd QP_State = Eigen::VectorXd::Zero(12);
    Eigen::MatrixXd EqualityConstraint_A_ = Eigen::MatrixXd::Zero(12, 12);
    Eigen::VectorXd EqualityConstraint_B_ = Eigen::VectorXd::Zero(12);
    Eigen::Matrix<qp_real, 12, 12> 	Cost_P; 
    Eigen::Matrix<qp_real, 12, 1> 	Cost_c; 
    Eigen::Matrix<qp_real, 24, 12> 	Inequality_G;
    Eigen::Matrix<qp_real, 24, 1> 	Inequality_h;
    Eigen::Matrix<qp_real, 12, 12> 	Equality_A; 
    Eigen::Matrix<qp_real, 12, 1> 	Equality_b; 

    Cost_P.block(0, 0, 12, 12) 		= A.block(0, 0, 12, 12);
    Cost_c.block(0, 0, 12, 1) 		= b.block(0, 0, 12, 1);

    Equality_A.block(0, 0, 12, 12)	= EqualityConstraint_A_.block(0, 0, 12, 12);	
    Equality_b.block(0, 0, 12, 1)	= EqualityConstraint_B_.block(0, 0, 12, 1);	

    Inequality_G.block(0, 0, 24, 12)= G.block(0, 0, 24, 12);
    Inequality_h.block(0, 0, 24, 1)	= h.block(0, 0, 24, 1);

    QP* SRBM;
    qp_int n = 12;      qp_int m = 24;      qp_int p = 12;	
    SRBM = QP_SETUP_dense(n, m, p, Cost_P.data(), Equality_A.data(), Inequality_G.data(), Cost_c.data(), Inequality_h.data(), Equality_b.data(), NULL, COLUMN_MAJOR_ORDERING);

    SRBM->options->maxit  = 30;   
    SRBM->options->reltol = 1e-6; 
    SRBM->options->abstol  = 1e-3; 	

    qp_int ExitCode_ = QP_SOLVE(SRBM);

    QP_State << 	SRBM->x[0],  SRBM->x[1],  SRBM->x[2],  
                    SRBM->x[3],  SRBM->x[4],  SRBM->x[5],  
                    SRBM->x[6],  SRBM->x[7],  SRBM->x[8], 
                    SRBM->x[9],  SRBM->x[10], SRBM->x[11];
    return QP_State;
}


/////////// Equality Constraint -> 없음 //////////


/////////// Inequality Constraint //////////
Eigen::Matrix<double,24,12> SingleRigidBody::SetInequalityConstraint_G(double mu)
{
    constexpr int kFeet = 4; // 다리 개수
    constexpr int kC = 6;    // 한 발당 부등식 제약 수
    constexpr int kV = 3;    // 한 발당 변수 수 (fx, fy, fz)

    Eigen::Matrix<double,24,12> G = Eigen::Matrix<double,24,12>::Zero();

    // 한 발(foot)에 대한 6x3 기본 블록
    Eigen::Matrix<double,kC,kV> Gfoot;
    Gfoot <<  1.0,  0.0,  mu,
             -1.0,  0.0,  mu,
              0.0,  1.0,  mu,
              0.0, -1.0,  mu,
              0.0,  0.0,  1.0,
              0.0,  0.0, -1.0;

    // 대각 블록으로 4개 발에 배치
    for (int i = 0; i < kFeet; ++i) {
        G.block<kC,kV>(i * kC, i * kV) = Gfoot;
    }

    return G;
}

Eigen::Matrix<double,24,1>  SingleRigidBody::SetInequalityConstraint_h(bool SW_FLAG[4], bool walking_flag)
{
    Eigen::Matrix<double,24,1> Inequality_h;
    if (walking_flag == true){
        Inequality_h << 
        0., 0., 0., 0., (-3.)*(1-SW_FLAG[_FL_]), (150.)*(1-SW_FLAG[_FL_]), 	
        0., 0., 0., 0., (-3.)*(1-SW_FLAG[_FR_]), (150.)*(1-SW_FLAG[_FR_]),
        0., 0., 0., 0., (-3.)*(1-SW_FLAG[_RL_]), (150.)*(1-SW_FLAG[_RL_]),
        0., 0., 0., 0., (-3.)*(1-SW_FLAG[_RR_]), (150.)*(1-SW_FLAG[_RR_]);	
    }
    else{
        Inequality_h << 
        0., 0., 0., 0., -1., 150.,
        0., 0., 0., 0., -1., 150.,
        0., 0., 0., 0., -1., 150.,
        0., 0., 0., 0., -1., 150.;	
    }
    return Inequality_h; 
}

/////////// Cost Function /////////////////
Eigen::Matrix<double,6,12> SingleRigidBody::Calc_Cost_A(const Eigen::Ref<const Eigen::MatrixXd>& foot_pos)
{
    Eigen::Matrix<double, 6, 12> A_Matrix;
    A_Matrix.setZero();

    const int legs[4] = { _FL_, _FR_, _RL_, _RR_ };
    const Eigen::Matrix3d negI = -Eigen::Matrix3d::Identity();

    for (int i = 0; i < 4; ++i) {
        const int leg = legs[i];
        const int col = 3 * i;

        const double x = foot_pos(_X_, leg);
        const double y = foot_pos(_Y_, leg);
        const double z = foot_pos(_Z_, leg);

        Eigen::Matrix3d S;
        S <<  0.0,  z,   -y,
             -z,   0.0,  x,
              y,  -x,   0.0;

        A_Matrix.block<3,3>(0, col) = S;     
        A_Matrix.block<3,3>(3, col) = negI;  
    }

    return A_Matrix;
}

Eigen::Matrix<double,6,1> SingleRigidBody::Calc_SRBM_Force( const Eigen::VectorXd& ref_pos,
                                                            const Eigen::VectorXd& ref_vel,
                                                            const Eigen::VectorXd& act_pos,
                                                            const Eigen::VectorXd& act_vel,
                                                            bool walking_flag)
{
   
    Eigen::Matrix<double,6,1> SRBM_Force(6);
    SRBM_Force.setZero();

    if (walking_flag == true){
        KP <<   0,     0, 2500, 5000, 4000, 2200;
        KD << 150,   220,  500,   25,   25,   50;
    }else{
        KP << 2000, 2000, 2500, 5000, 4000, 2200;
        KD << 50,   50,   500,   25,   25,   50;
    }
    Eigen::Matrix<double,6,1> pos_error = ref_pos - act_pos;
    Eigen::Matrix<double,6,1> vel_error = ref_vel - act_vel;

    Eigen::Matrix<double,6,1> Temp_force(6);
    Temp_force.setZero();
    Temp_force = KP.asDiagonal() * pos_error + KD.asDiagonal() * vel_error;
    SRBM_Force.segment<3>(0) = Temp_force.segment<3>(3);
    SRBM_Force.segment<3>(3) = Temp_force.segment<3>(0); 

    // SRBM_Force(0) += ROBOT_M * 9.81; // CoM의 z축 방향 중력 보정

    return SRBM_Force; 
}
Eigen::MatrixXd SingleRigidBody::SetCostFunction_A( Eigen::MatrixXd A_Matrix ) 
{
    Eigen::MatrixXd Cost_A = A_Matrix.transpose() * A_Matrix;
    return Cost_A; // Eigen::VectorXd 로 암시적 변환 반환
}

Eigen::VectorXd SingleRigidBody::SetCostFunction_B(Eigen::MatrixXd A_Matrix, Eigen::VectorXd SRBM_Force)
{
    Eigen::VectorXd Cost_B(12);
    Cost_B = -1 * A_Matrix.transpose() * SRBM_Force;
    return Cost_B;
}