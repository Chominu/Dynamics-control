// MPC.cpp
#include "MPC.h"

MPCController::MPCController(int horizon, double dt)
 : N_(horizon), NX_(12), NU_(12), dt_(dt)
{}

MPCController::~MPCController() {}

// solve()에서 z_solution을 구한 뒤, 앞 NU_원소(u0)를 반환
Eigen::VectorXd MPCController::solve(
    const Eigen::VectorXd& x0,
    const std::vector<Eigen::VectorXd>& x_ref)
{
  int n = N_*(NU_ + NX_);            // QP 변수 개수
  int p = N_*NX_;                    // equality constraints 수
//   int m = /* 스윙·마찰 등 포함한 부등식 제약 총수 */;
  int m =N_*NU_*2; 

  Eigen::VectorXd z_sol(n);
  buildAndSolveQP(x0, x_ref, z_sol);

  // 첫 제어 벡터 u0 반환
  return z_sol.head(NU_);
}

void MPCController::buildAndSolveQP(
    const Eigen::VectorXd& x0,
    const std::vector<Eigen::VectorXd>& x_ref,
    Eigen::VectorXd& z_solution)
{
  int n = N_*(NU_ + NX_);
  int p = N_*NX_;
  int m = N_*NU_*2;

  // qpSWIFT에 넣을 데이터
  std::vector<qp_real> P_qp(n*n),   // Hessian
                      q_qp(n),     // cost linear term
                      A_qp(p*n),   // equality A
                      b_qp(p),     // equality b
                      G_qp(m*n),   // inequality G
                      h_qp(m);     // inequality h

  // --- 1) Cost 함수 세팅 ---
  // Cost = 0.5 z^T P z + q^T z
  // P, q 를 Eigen에서 채워준 뒤 column-major로 복사
  // 예) P_qp[i + j*n] = P_eigen(j,i);
  //    q_qp[i]      = q_eigen(i);

  // --- 2) Equality constraint: A_eq z = b_eq ---
  // 동역학 매트릭스 A_d_k, B_d_k를 계산하고,
  // z = [u0,x1,u1,x2,...] 순서대로 A_qp, b_qp 채움

  // --- 3) Inequality constraint: G z <= h ---
  // 수직력 ≥ 0, ≤ fz_max, 마찰 콘, 스윙 스케줄 등
  // G_qp, h_qp에 채워넣기

  // --- 4) qpSWIFT 호출 ---
  QP* mpc = QP_SETUP_dense(
    /*n=*/n, /*m=*/m, /*p=*/p,
    P_qp.data(),
    A_qp.data(),
    G_qp.data(),
    q_qp.data(),
    h_qp.data(),
    b_qp.data(),
    /*lb=*/NULL,                 // lower bounds (없으면 NULL)
    COLUMN_MAJOR_ORDERING
  );

  // solver 옵션
  mpc->options->maxit   = 100;
  mpc->options->reltol  = 1e-4;
  mpc->options->abstol  = 1e-4;

  // QP 풀기
  QP_SOLVE(mpc);

  // 결과 복사
  for(int i=0; i<n; ++i) {
    z_solution(i) = mpc->x[i];
  }

  QP_CLEANUP(mpc);
}
