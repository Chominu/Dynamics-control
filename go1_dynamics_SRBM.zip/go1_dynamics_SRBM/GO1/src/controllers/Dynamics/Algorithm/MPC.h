// MPC.h
#pragma once
#include <Eigen/Dense>
#include "qpSWIFT.h"    // qpSWIFT C API

class MPCController {
public:
  MPCController(int horizon, double dt);
  ~MPCController();

  // x0: 현재 상태(NX×1), x_ref: 예측 지평선 상태 레퍼런스(N×NX)
  // returns: 첫 번째 제어(u0: NU×1)
  Eigen::VectorXd solve(const Eigen::VectorXd& x0,
                        const std::vector<Eigen::VectorXd>& x_ref);

private:
  int N_, NX_, NU_;
  double dt_;

  // 내부에서 매번 build 후 QP 풀기
  void buildAndSolveQP(const Eigen::VectorXd& x0,
                       const std::vector<Eigen::VectorXd>& x_ref,
                       Eigen::VectorXd& z_solution);
};
