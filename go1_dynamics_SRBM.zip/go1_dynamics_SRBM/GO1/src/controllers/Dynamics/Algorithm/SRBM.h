#ifndef SRBM_H
#define SRBM_H

#include <iostream>
#include <Eigen/Dense>
#include <cmath>
#include "qpSWIFT.h" 
#include "enum.h"
class SingleRigidBody
{ 
public:
    SingleRigidBody();
    ~SingleRigidBody();
    Eigen::Matrix<double,6,12> Calc_Cost_A(const Eigen::Ref<const Eigen::MatrixXd>& foot_pos);

    Eigen::Matrix<double,6,1>  Calc_SRBM_Force( const Eigen::VectorXd& ref_pos,
                                                const Eigen::VectorXd& ref_vel,
                                                const Eigen::VectorXd& act_pos,
                                                const Eigen::VectorXd& act_vel,
                                                bool walking_flag);
    Eigen::MatrixXd SetCostFunction_A( Eigen::MatrixXd A_Matrix ) ;
    Eigen::VectorXd SetCostFunction_B( Eigen::MatrixXd A_Matrix, Eigen::VectorXd SRBM_Force);

    Eigen::Matrix<double,24,12> SetInequalityConstraint_G(double mu);

    Eigen::Matrix<double,24,1>  SetInequalityConstraint_h(bool SW_FLAG[4], bool walking_flag);

    Eigen::Matrix<double,12,1> SRBM_QP( const Eigen::Ref<const Eigen::Matrix<double,12,12>>& A,
                                        const Eigen::Ref<const Eigen::Matrix<double,12,1>>&  b,
                                        const Eigen::Ref<const Eigen::Matrix<double,24,12>>& G,
                                        const Eigen::Ref<const Eigen::Matrix<double,24,1>>&  h);
    
private:
    Eigen::VectorXd KP = Eigen::VectorXd::Zero(6);
    Eigen::VectorXd KD = Eigen::VectorXd::Zero(6);
};

#endif // SRBM_H
